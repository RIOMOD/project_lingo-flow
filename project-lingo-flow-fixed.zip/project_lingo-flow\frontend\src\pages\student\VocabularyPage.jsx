import { useEffect, useState } from "react";
import { EmptyState, LoadingState } from "../../components/common/UiState";
import { getReviewVocabularies, getVocabularies, updateVocabularyProgress } from "../../services/learningService";

export default function VocabularyPage() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [level, setLevel] = useState("");
  const [reviewOnly, setReviewOnly] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load() {
    try {
      setLoading(true);
      setError("");
      const data = reviewOnly
        ? await getReviewVocabularies({ size: 20 })
        : await getVocabularies({ search, level, size: 20 });
      setItems(data?.items ?? []);
    } catch (err) {
      setError(err.message || "Không tải được từ vựng");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [search, level, reviewOnly]);

  async function mark(id, payload) {
    try {
      const updated = await updateVocabularyProgress(id, payload);
      setItems((current) => current.map((item) => (item.id === id ? updated : item)));
    } catch (err) {
      setError(err.message || "Không cập nhật được tiến độ");
    }
  }

  return (
    <div className="student-page">
      <section className="student-hero compact">
        <div>
          <span className="page-badge">Vocabulary</span>
          <h2>Flashcard từ vựng</h2>
          <p>Nghe phát âm, xem ví dụ, đánh dấu đã nhớ, từ khó và từ yêu thích.</p>
        </div>
        <div className="student-vocab-filter">
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm từ hoặc nghĩa" />
          <select value={level} onChange={(event) => setLevel(event.target.value)}>
            <option value="">Mọi level</option>
            <option value="BEGINNER">Beginner</option>
            <option value="ELEMENTARY">Elementary</option>
            <option value="INTERMEDIATE">Intermediate</option>
            <option value="ADVANCED">Advanced</option>
          </select>
          <button className="page-action page-action-secondary" onClick={() => setReviewOnly((value) => !value)}>
            {reviewOnly ? "Tắt ôn tập" : "Từ cần ôn"}
          </button>
        </div>
      </section>

      {error && <p className="auth-error">{error}</p>}
      {loading && <LoadingState title="Đang tải từ vựng..." />}
      {!loading && !error && items.length === 0 && (
        <EmptyState title="Chưa có từ vựng" description="Hãy thử bộ lọc khác hoặc học thêm bài mới để có từ cần ôn." />
      )}

      <section className="student-flashcard-grid">
        {items.map((item) => (
          <article className="student-flashcard" key={item.id}>
            <div className="student-flashcard-head">
              <span>{item.level}</span>
              <span>{item.topic || item.partOfSpeech}</span>
            </div>
            <h3>{item.word}</h3>
            <p className="student-ipa">{item.ipa || "Chưa có IPA"}</p>
            <p className="student-meaning">{item.meaning}</p>
            <p className="student-example">{item.exampleSentence || "Chưa có câu ví dụ."}</p>
            {item.exampleMeaning && <p className="student-example-meaning">{item.exampleMeaning}</p>}
            {item.audioUrl && <audio controls src={item.audioUrl} />}
            <div className="student-flashcard-actions">
              <button
                className="page-action page-action-primary"
                onClick={() => mark(item.id, { remembered: true, masteryLevel: Math.min((item.masteryLevel || 0) + 1, 5), difficult: false })}
              >
                Đã nhớ
              </button>
              <button className="page-action page-action-secondary" onClick={() => mark(item.id, { difficult: !item.difficult })}>
                {item.difficult ? "Bỏ khó" : "Khó"}
              </button>
              <button className="page-action page-action-secondary" onClick={() => mark(item.id, { favorite: !item.favorite })}>
                {item.favorite ? "Bỏ thích" : "Yêu thích"}
              </button>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}

