package com.example.englishlearning.dto.progress;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
@Builder
public class CourseProgressResponse {
    private Long courseId;
    private String courseTitle;
    private long totalLessons;
    private long startedLessons;
    private long completedLessons;
    private BigDecimal progressPercent;
    private Integer studyTimeMinutes;
    private String nextLessonTitle;
}
