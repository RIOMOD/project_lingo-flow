package com.example.englishlearning.repository;

import com.example.englishlearning.entity.TestAttempt;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TestAttemptRepository extends JpaRepository<TestAttempt, Long> {
    long countByUserIdAndTestId(Long userId, Long testId);
    long countByUserIdAndExerciseId(Long userId, Long exerciseId);
    Page<TestAttempt> findByUserIdOrderByStartedAtDesc(Long userId, Pageable pageable);
    List<TestAttempt> findByUserIdAndSubmittedAtIsNotNull(Long userId);
    Page<TestAttempt> findByTestCourseTeacherIdOrExerciseCourseTeacherIdOrderByStartedAtDesc(Long testTeacherId, Long exerciseTeacherId, Pageable pageable);
}
