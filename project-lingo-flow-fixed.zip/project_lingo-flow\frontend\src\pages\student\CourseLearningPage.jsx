import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { LoadingState } from "../../components/common/UiState";
import { getCourseChapters, getLesson } from "../../services/courseService";
import { completeLessonProgress, startLessonProgress } from "../../services/progressService";

function flattenLessons(chapters) {
  return chapters.flatMap((chapter) =>
    (chapter.lessons ?? []).map((lesson) => ({
      ...lesson,
      chapterTitle: chapter.title,
    })),
  );
}

function isPreviewLesson(lesson) {
  return Boolean(lesson?.preview ?? lesson?.isPreview);
}

export default function CourseLearningPage() {
  const { courseId } = useParams();
  const [chapters, setChapters] = useState([]);
  const [activeLessonId, setActiveLessonId] = useState(null);
  const [lesson, setLesson] = useState(null);
  const [courseProgress, setCourseProgress] = useState(null);
  const [studyMinutes, setStudyMinutes] = useState(10);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loadingLesson, setLoadingLesson] = useState(false);

  const lessons = useMemo(() => flattenLessons(chapters), [chapters]);
  const activeLesson = lessons.find((item) => item.id === activeLessonId);

  useEffect(() => {
    let mounted = true;
    setError("");

    getCourseChapters(courseId)
      .then((data) => {
        if (!mounted) return;
        const safeChapters = data ?? [];
        setChapters(safeChapters);
        const firstUnlocked = flattenLessons(safeChapters).find((item) => !item.locked);
        if (firstUnlocked) setActiveLessonId(firstUnlocked.id);
      })
      .catch((err) => {
        if (mounted) setError(err.message || "Không tải được danh sách bài học");
      });

    return () => {
      mounted = false;
    };
  }, [courseId]);

  useEffect(() => {
    if (!activeLessonId) return;
    let mounted = true;
    setLoadingLesson(true);
    setMessage("");

    getLesson(courseId, activeLessonId)
      .then(async (data) => {
        if (!mounted) return;
        setLesson(data);
        const progress = await startLessonProgress(activeLessonId, { studyTimeMinutes: 0 });
        if (mounted) setCourseProgress(progress);
      })
      .catch((err) => {
        if (mounted) setError(err.message || "Không mở được bài học");
      })
      .finally(() => {
        if (mounted) setLoadingLesson(false);
      });

    return () => {
      mounted = false;
    };
  }, [courseId, activeLessonId]);

  async function handleCompleteLesson() {
    if (!activeLessonId) return;

    try {
      const progress = await completeLessonProgress(activeLessonId, {
        studyTimeMinutes: Number(studyMinutes) || 0,
      });
      setCourseProgress(progress);
      setMessage("Đã cập nhật tiến độ bài học.");
    } catch (err) {
      setError(err.message || "Không cập nhật được tiến độ");
    }
  }

  return (
    <div className="student-page">
      <section className="student-learning-hero">
        <div>
          <span className="page-badge">Learning Room</span>
          <h2>{lesson?.title || "Đang học khóa học"}</h2>
          <p>{activeLesson?.chapterTitle || "Chọn bài học để bắt đầu."}</p>
        </div>
        <div className="student-learning-meta">
          <span>{lesson?.lessonType || "LESSON"}</span>
          <strong>{courseProgress ? `${Number(courseProgress.progressPercent || 0).toFixed(0)}%` : "0%"}</strong>
          <small>Tiến độ khóa học</small>
        </div>
      </section>

      {error && <p className="auth-error">{error}</p>}
      {message && <p className="course-success">{message}</p>}

      <section className="student-learning-shell">
        <aside className="student-lesson-sidebar">
          <h3>Danh sách bài học</h3>
          <div className="student-lesson-list">
            {chapters.map((chapter) => (
              <div key={chapter.id} className="student-lesson-group">
                <h4>{chapter.position}. {chapter.title}</h4>
                {(chapter.lessons ?? []).map((item) => (
                  <button
                    className={`student-lesson-button ${item.id === activeLessonId ? "is-active" : ""} ${item.locked ? "is-locked" : ""}`}
                    disabled={item.locked}
                    key={item.id}
                    onClick={() => setActiveLessonId(item.id)}
                    type="button"
                  >
                    <span>{item.position}. {item.title}</span>
                    <small>{item.locked ? "Bị khóa" : isPreviewLesson(item) ? "Học thử" : `${item.durationMinutes || 0} phút`}</small>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </aside>

        <article className="student-lesson-content">
          {loadingLesson && <LoadingState title="Đang tải bài học..." />}
          {!loadingLesson && lesson && (
            <>
              {lesson.videoUrl && <iframe src={lesson.videoUrl} title={lesson.title} allowFullScreen />}
              {lesson.audioUrl && <audio src={lesson.audioUrl} controls />}
              <div className="student-lesson-text">
                <span className="page-badge">{lesson.lessonType}</span>
                <h3>{lesson.title}</h3>
                <p>{lesson.content || "Bài học này chưa có nội dung text."}</p>
              </div>
            </>
          )}
          {!loadingLesson && !lesson && <LoadingState title="Chọn một bài học để bắt đầu" description="Danh sách bài học nằm ở cột bên trái." />}
        </article>

        <aside className="student-progress-card">
          <h3>Hoàn thành bài học</h3>
          <p>
            {courseProgress
              ? `${courseProgress.completedLessons}/${courseProgress.totalLessons} bài - ${Number(courseProgress.progressPercent || 0).toFixed(0)}%`
              : "Chưa có dữ liệu tiến độ."}
          </p>
          <label className="auth-field">
            Phút học thêm
            <input
              min="0"
              type="number"
              value={studyMinutes}
              onChange={(event) => setStudyMinutes(event.target.value)}
            />
          </label>
          <button className="page-action page-action-primary" onClick={handleCompleteLesson} type="button">
            Đánh dấu hoàn thành
          </button>
          <div className="student-next-lesson">
            <span>Đề xuất tiếp theo</span>
            <strong>{courseProgress?.nextLessonTitle || "Đã hoàn thành"}</strong>
          </div>
        </aside>
      </section>
    </div>
  );
}

