import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import {
  navigationByRole,
  roleMeta,
  roleSwitches,
} from "../../config/navigation";
import {
  isNavigationItemActive,
  resolveNavigationSection,
  resolvePageContext,
} from "../../config/pageContext";

export default function AppShell({ roleKey }) {
  const role = roleMeta[roleKey];
  const sections = navigationByRole[roleKey];
  const location = useLocation();
  const currentPage = resolvePageContext(location.pathname)?.config;
  const currentSection = resolveNavigationSection(roleKey, location.pathname);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    setIsSidebarOpen(false);
  }, [location.pathname]);

  return (
    <div
      className="app-shell"
      style={{
        "--role-accent": role.accent,
        "--role-accent-soft": `${role.accent}18`,
        "--role-accent-border": `${role.accent}40`,
      }}
    >
      <button
        type="button"
        className="app-mobile-trigger"
        onClick={() => setIsSidebarOpen((open) => !open)}
        aria-expanded={isSidebarOpen}
        aria-label={isSidebarOpen ? "Close navigation" : "Open navigation"}
      >
        {isSidebarOpen ? "Close" : "Menu"}
      </button>

      <button
        type="button"
        className={`app-sidebar-overlay ${isSidebarOpen ? "is-visible" : ""}`}
        onClick={() => setIsSidebarOpen(false)}
        aria-hidden={!isSidebarOpen}
        tabIndex={isSidebarOpen ? 0 : -1}
      />

      <aside className={`app-sidebar ${isSidebarOpen ? "is-open" : ""}`}>
        <div className="app-sidebar-head">
          <span className="app-role-badge">{role.label}</span>
          <Link to={role.homePath} className="app-brand-title">
            English Smart Learning
          </Link>
          <p className="app-brand-text">{role.description}</p>
        </div>

        {sections.map((section) => (
          <section key={section.title} className="app-nav-section">
            <p className="app-nav-title">{section.title}</p>
            <div className="app-nav-list">
              {section.items.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={`app-nav-item ${
                    isNavigationItemActive(item, location.pathname)
                      ? "is-active"
                      : ""
                  }`}
                >
                  {item.label}
                </NavLink>
              ))}
            </div>
          </section>
        ))}

        <div className="app-sidebar-footer">
          <p className="app-sidebar-caption">Quick switch</p>
          <div className="app-switch-pills">
            {roleSwitches.map((switchItem) => (
              <Link
                key={switchItem.to}
                to={switchItem.to}
                className={`app-switch-pill ${
                  switchItem.to === role.homePath ? "is-current" : ""
                }`}
              >
                {switchItem.label}
              </Link>
            ))}
          </div>
        </div>
      </aside>

      <div className="app-content">
        <header className="app-topbar">
          <div className="app-topbar-copy">
            <span className="app-eyebrow">
              {currentSection?.title ?? role.label}
            </span>
            <h1 className="app-topbar-title">
              {currentPage?.title ?? role.title}
            </h1>
            <p className="app-topbar-text">
              {currentPage?.description ?? role.description}
            </p>
            <div className="app-topbar-meta">
              <span className="app-topbar-chip">{role.label}</span>
              {currentSection && (
                <span className="app-topbar-chip">{currentSection.title}</span>
              )}
              <span className="app-topbar-chip app-topbar-chip-path">
                {location.pathname}
              </span>
            </div>
          </div>

          <div className="app-topbar-switches">
            {roleSwitches.map((switchItem) => (
              <Link
                key={switchItem.to}
                to={switchItem.to}
                className={`app-topbar-switch ${
                  switchItem.to === role.homePath ? "is-current" : ""
                }`}
              >
                {switchItem.label}
              </Link>
            ))}
          </div>
        </header>

        <main className="app-main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
