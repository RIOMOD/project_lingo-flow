package com.example.englishlearning.service.impl;

import com.example.englishlearning.dto.progress.ChartPointResponse;
import com.example.englishlearning.dto.progress.CourseProgressResponse;
import com.example.englishlearning.dto.progress.LessonProgressRequest;
import com.example.englishlearning.dto.progress.ProgressDashboardResponse;
import com.example.englishlearning.dto.progress.SkillProgressResponse;
import com.example.englishlearning.entity.Course;
import com.example.englishlearning.entity.CourseEnrollment;
import com.example.englishlearning.entity.CourseOwnership;
import com.example.englishlearning.entity.Exercise;
import com.example.englishlearning.entity.LearningProgress;
import com.example.englishlearning.entity.Lesson;
import com.example.englishlearning.entity.TestAttempt;
import com.example.englishlearning.entity.User;
import com.example.englishlearning.exception.ResourceNotFoundException;
import com.example.englishlearning.exception.UnauthorizedException;
import com.example.englishlearning.repository.CourseEnrollmentRepository;
import com.example.englishlearning.repository.CourseOwnershipRepository;
import com.example.englishlearning.repository.CourseRepository;
import com.example.englishlearning.repository.LearningProgressRepository;
import com.example.englishlearning.repository.LessonRepository;
import com.example.englishlearning.repository.TestAttemptRepository;
import com.example.englishlearning.repository.UserRepository;
import com.example.englishlearning.repository.VocabularyProgressRepository;
import com.example.englishlearning.service.ProgressService;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ProgressServiceImpl implements ProgressService {

    private final LearningProgressRepository progressRepository;
    private final CourseEnrollmentRepository enrollmentRepository;
    private final CourseOwnershipRepository ownershipRepository;
    private final CourseRepository courseRepository;
    private final LessonRepository lessonRepository;
    private final TestAttemptRepository attemptRepository;
    private final VocabularyProgressRepository vocabularyProgressRepository;
    private final UserRepository userRepository;

    public ProgressServiceImpl(
            LearningProgressRepository progressRepository,
            CourseEnrollmentRepository enrollmentRepository,
            CourseOwnershipRepository ownershipRepository,
            CourseRepository courseRepository,
            LessonRepository lessonRepository,
            TestAttemptRepository attemptRepository,
            VocabularyProgressRepository vocabularyProgressRepository,
            UserRepository userRepository
    ) {
        this.progressRepository = progressRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.ownershipRepository = ownershipRepository;
        this.courseRepository = courseRepository;
        this.lessonRepository = lessonRepository;
        this.attemptRepository = attemptRepository;
        this.vocabularyProgressRepository = vocabularyProgressRepository;
        this.userRepository = userRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public ProgressDashboardResponse getStudentDashboard(String email) {
        User user = getUser(email);
        List<CourseProgressResponse> courses = getCourseProgress(email);
        List<LearningProgress> progress = progressRepository.findByUserIdOrderByLastAccessedAtDesc(user.getId());
        List<TestAttempt> attempts = attemptRepository.findByUserIdAndSubmittedAtIsNotNull(user.getId());
        return ProgressDashboardResponse.builder()
                .activeCourses(courses.size())
                .startedLessons(progress.stream().filter(item -> item.getStatus() != LearningProgress.ProgressStatus.NOT_STARTED).count())
                .completedLessons(progress.stream().filter(this::isFullCompletion).count())
                .learnedWords(vocabularyProgressRepository.countByUserId(user.getId()))
                .rememberedWords(vocabularyProgressRepository.countByUserIdAndRememberedTrue(user.getId()))
                .studyTimeMinutes(progress.stream().mapToInt(item -> item.getStudyTimeMinutes() == null ? 0 : item.getStudyTimeMinutes()).sum())
                .streakDays(calculateStreak(user.getId()))
                .strongestSkill(resolveSkill(attempts, true))
                .weakestSkill(resolveSkill(attempts, false))
                .weeklyChart(buildWeeklyChart(user.getId()))
                .monthlyChart(buildMonthlyChart(user.getId()))
                .courses(courses)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseProgressResponse> getCourseProgress(String email) {
        User user = getUser(email);
        return enrollmentRepository.findByUserIdAndStatus(user.getId(), CourseEnrollment.EnrollmentStatus.ACTIVE)
                .stream()
                .filter(enrollment -> hasCourseAccess(user, enrollment.getCourse()))
                .map(enrollment -> buildCourseProgress(user.getId(), enrollment.getCourse()))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public CourseProgressResponse getCourseProgress(String email, Long courseId) {
        User user = getUser(email);
        Course course = getCourse(courseId);
        ensureCourseAccess(user, course, false);
        return buildCourseProgress(user.getId(), course);
    }

    @Override
    public CourseProgressResponse startLesson(String email, Long lessonId, LessonProgressRequest request) {
        User user = getUser(email);
        Lesson lesson = getLesson(lessonId);
        boolean previewOnly = ensureCourseAccess(user, lesson.getChapter().getCourse(), Boolean.TRUE.equals(lesson.getPreview()));
        LearningProgress progress = getOrCreateProgress(user, lesson);
        if (progress.getStatus() == LearningProgress.ProgressStatus.NOT_STARTED) {
            progress.setStatus(LearningProgress.ProgressStatus.IN_PROGRESS);
            progress.setStartedAt(LocalDateTime.now());
            progress.setProgressPercent(new BigDecimal("10.00"));
        }
        progress.setPreviewOnly(previewOnly);
        progress.setLastAccessedAt(LocalDateTime.now());
        progress.setStudyTimeMinutes(safe(progress.getStudyTimeMinutes()) + safe(request.getStudyTimeMinutes()));
        progressRepository.save(progress);
        return buildCourseProgress(user.getId(), lesson.getChapter().getCourse());
    }

    @Override
    public CourseProgressResponse completeLesson(String email, Long lessonId, LessonProgressRequest request) {
        User user = getUser(email);
        Lesson lesson = getLesson(lessonId);
        boolean previewOnly = ensureCourseAccess(user, lesson.getChapter().getCourse(), Boolean.TRUE.equals(lesson.getPreview()));
        if (previewOnly && !Boolean.TRUE.equals(lesson.getPreview())) {
            throw new UnauthorizedException("Locked lesson cannot be completed");
        }
        LearningProgress progress = getOrCreateProgress(user, lesson);
        progress.setStatus(LearningProgress.ProgressStatus.COMPLETED);
        progress.setProgressPercent(new BigDecimal("100.00"));
        progress.setPreviewOnly(previewOnly);
        progress.setCompletedAt(LocalDateTime.now());
        progress.setLastAccessedAt(LocalDateTime.now());
        progress.setStudyTimeMinutes(safe(progress.getStudyTimeMinutes()) + safe(request.getStudyTimeMinutes()));
        progress.setScore(request.getScore());
        progressRepository.save(progress);
        return buildCourseProgress(user.getId(), lesson.getChapter().getCourse());
    }

    @Override
    @Transactional(readOnly = true)
    public ProgressDashboardResponse getTeacherDashboard(String email) {
        User teacher = getUser(email);
        var courses = courseRepository.findByTeacherIdAndDeletedAtIsNullOrderByUpdatedAtDesc(teacher.getId(), PageRequest.of(0, 200)).getContent();
        var attempts = attemptRepository.findByTestCourseTeacherIdOrExerciseCourseTeacherIdOrderByStartedAtDesc(
                teacher.getId(), teacher.getId(), PageRequest.of(0, 500)
        ).getContent();
        return ProgressDashboardResponse.builder()
                .activeCourses(courses.size())
                .startedLessons(attempts.size())
                .completedLessons(attempts.stream().filter(item -> item.getSubmittedAt() != null).count())
                .studyTimeMinutes(0)
                .streakDays(0)
                .strongestSkill(resolveSkill(attempts, true))
                .weakestSkill(resolveSkill(attempts, false))
                .weeklyChart(buildAttemptWeeklyChart(attempts))
                .monthlyChart(buildAttemptMonthlyChart(attempts))
                .courses(List.of())
                .build();
    }

    private LearningProgress getOrCreateProgress(User user, Lesson lesson) {
        return progressRepository.findByUserIdAndLessonId(user.getId(), lesson.getId()).orElseGet(() -> {
            LearningProgress progress = new LearningProgress();
            progress.setUser(user);
            progress.setCourse(lesson.getChapter().getCourse());
            progress.setLesson(lesson);
            return progress;
        });
    }

    private CourseProgressResponse buildCourseProgress(Long userId, Course course) {
        long totalLessons = lessonRepository.countByChapterCourseIdAndDeletedAtIsNull(course.getId());
        List<LearningProgress> items = progressRepository.findByUserIdAndCourseId(userId, course.getId());
        long started = items.stream().filter(item -> item.getStatus() != LearningProgress.ProgressStatus.NOT_STARTED).count();
        long completed = items.stream().filter(this::isFullCompletion).count();
        Integer studyTime = items.stream().mapToInt(item -> safe(item.getStudyTimeMinutes())).sum();
        BigDecimal percent = totalLessons == 0
                ? BigDecimal.ZERO
                : BigDecimal.valueOf(completed).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(totalLessons), 2, RoundingMode.HALF_UP);
        String nextLesson = lessonRepository.findByChapterCourseIdAndDeletedAtIsNullOrderByPositionAsc(course.getId())
                .stream()
                .filter(lesson -> items.stream().noneMatch(item -> item.getLesson().getId().equals(lesson.getId())
                        && isFullCompletion(item)))
                .map(Lesson::getTitle)
                .findFirst()
                .orElse(null);
        return CourseProgressResponse.builder()
                .courseId(course.getId())
                .courseTitle(course.getTitle())
                .totalLessons(totalLessons)
                .startedLessons(started)
                .completedLessons(completed)
                .progressPercent(percent)
                .studyTimeMinutes(studyTime)
                .nextLessonTitle(nextLesson)
                .build();
    }

    private boolean ensureCourseAccess(User user, Course course, boolean allowPreview) {
        boolean freeAccess = course.getCourseType() == Course.CourseType.FREE
                && enrollmentRepository.existsByUserIdAndCourseIdAndStatus(user.getId(), course.getId(), CourseEnrollment.EnrollmentStatus.ACTIVE);
        boolean paidAccess = course.getCourseType() == Course.CourseType.PAID
                && ownershipRepository.existsByUserIdAndCourseIdAndStatus(user.getId(), course.getId(), CourseOwnership.OwnershipStatus.ACTIVE);
        if (freeAccess || paidAccess || "ADMIN".equals(user.getRole().getCode())) {
            return false;
        }
        if (allowPreview) {
            return true;
        }
        throw new UnauthorizedException("You do not have access to this course");
    }

    private boolean hasCourseAccess(User user, Course course) {
        boolean freeAccess = course.getCourseType() == Course.CourseType.FREE
                && enrollmentRepository.existsByUserIdAndCourseIdAndStatus(user.getId(), course.getId(), CourseEnrollment.EnrollmentStatus.ACTIVE);
        boolean paidAccess = course.getCourseType() == Course.CourseType.PAID
                && ownershipRepository.existsByUserIdAndCourseIdAndStatus(user.getId(), course.getId(), CourseOwnership.OwnershipStatus.ACTIVE);
        return freeAccess || paidAccess || "ADMIN".equals(user.getRole().getCode());
    }

    private boolean isFullCompletion(LearningProgress progress) {
        return progress.getStatus() == LearningProgress.ProgressStatus.COMPLETED
                && !Boolean.TRUE.equals(progress.getPreviewOnly());
    }

    private Integer calculateStreak(Long userId) {
        int streak = 0;
        LocalDate day = LocalDate.now();
        while (true) {
            LocalDateTime start = day.atStartOfDay();
            LocalDateTime end = day.plusDays(1).atStartOfDay();
            if (progressRepository.countByUserIdAndLastAccessedAtBetween(userId, start, end) == 0) {
                return streak;
            }
            streak++;
            day = day.minusDays(1);
        }
    }

    private List<ChartPointResponse> buildWeeklyChart(Long userId) {
        LocalDate today = LocalDate.now();
        return java.util.stream.IntStream.rangeClosed(0, 6)
                .mapToObj(offset -> today.minusDays(6L - offset))
                .map(day -> ChartPointResponse.builder()
                        .label(day.toString())
                        .value(progressRepository.countByUserIdAndLastAccessedAtBetween(userId, day.atStartOfDay(), day.plusDays(1).atStartOfDay()))
                        .build())
                .toList();
    }

    private List<ChartPointResponse> buildMonthlyChart(Long userId) {
        YearMonth month = YearMonth.now();
        return java.util.stream.IntStream.rangeClosed(1, month.lengthOfMonth())
                .mapToObj(month::atDay)
                .map(day -> ChartPointResponse.builder()
                        .label(String.valueOf(day.getDayOfMonth()))
                        .value(progressRepository.countByUserIdAndLastAccessedAtBetween(userId, day.atStartOfDay(), day.plusDays(1).atStartOfDay()))
                        .build())
                .toList();
    }

    private List<ChartPointResponse> buildAttemptWeeklyChart(List<TestAttempt> attempts) {
        LocalDate today = LocalDate.now();
        return java.util.stream.IntStream.rangeClosed(0, 6)
                .mapToObj(offset -> today.minusDays(6L - offset))
                .map(day -> ChartPointResponse.builder()
                        .label(day.toString())
                        .value(attempts.stream().filter(item -> sameDay(item.getStartedAt(), day)).count())
                        .build())
                .toList();
    }

    private List<ChartPointResponse> buildAttemptMonthlyChart(List<TestAttempt> attempts) {
        YearMonth month = YearMonth.now();
        return java.util.stream.IntStream.rangeClosed(1, month.lengthOfMonth())
                .mapToObj(month::atDay)
                .map(day -> ChartPointResponse.builder()
                        .label(String.valueOf(day.getDayOfMonth()))
                        .value(attempts.stream().filter(item -> sameDay(item.getStartedAt(), day)).count())
                        .build())
                .toList();
    }

    private SkillProgressResponse resolveSkill(List<TestAttempt> attempts, boolean strongest) {
        Map<String, List<TestAttempt>> bySkill = new LinkedHashMap<>();
        for (TestAttempt attempt : attempts) {
            if (attempt.getScore() == null) continue;
            String skill = attempt.getExercise() == null ? "TEST" : attempt.getExercise().getExerciseType().name();
            bySkill.computeIfAbsent(skill, key -> new java.util.ArrayList<>()).add(attempt);
        }
        return bySkill.entrySet().stream()
                .map(entry -> SkillProgressResponse.builder()
                        .skill(entry.getKey())
                        .attempts(entry.getValue().size())
                        .averageScore(entry.getValue().stream()
                                .map(TestAttempt::getScore)
                                .reduce(BigDecimal.ZERO, BigDecimal::add)
                                .divide(BigDecimal.valueOf(entry.getValue().size()), 2, RoundingMode.HALF_UP))
                        .build())
                .sorted(strongest
                        ? Comparator.comparing(SkillProgressResponse::getAverageScore).reversed()
                        : Comparator.comparing(SkillProgressResponse::getAverageScore))
                .findFirst()
                .orElse(null);
    }

    private boolean sameDay(LocalDateTime value, LocalDate day) {
        return value != null && value.toLocalDate().equals(day);
    }

    private Lesson getLesson(Long lessonId) {
        return lessonRepository.findById(lessonId)
                .filter(item -> item.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Lesson not found"));
    }

    private Course getCourse(Long courseId) {
        return courseRepository.findById(courseId)
                .filter(item -> item.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found"));
    }

    private User getUser(String email) {
        return userRepository.findByEmailAndDeletedAtIsNull(email)
                .orElseThrow(() -> new UnauthorizedException("Authentication is required"));
    }

    private int safe(Integer value) {
        return value == null ? 0 : value;
    }
}
