import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { LoadingState } from "../../components/common/UiState";
import { getProgressDashboard } from "../../services/progressService";

function MiniBarChart({ items = [] }) {
  const max = Math.max(1, ...items.map((item) => item.value || 0));

  return (
    <div className="student-chart">
      {items.map((item) => (
        <div className="student-chart-row" key={item.label}>
          <span>{item.label}</span>
          <div>
            <i style={{ width: `${((item.value || 0) / max) * 100}%` }} />
          </div>
          <strong>{item.value}</strong>
        </div>
      ))}
    </div>
  );
}

export default function StudentDashboardPage() {
  const [dashboard, setDashboard] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getProgressDashboard()
      .then(setDashboard)
      .catch((err) => setError(err.message || "Không tải được dashboard"));
  }, []);

  const stats = [
    { label: "Khóa đang học", value: dashboard?.activeCourses ?? 0 },
    { label: "Bài đã hoàn thành", value: dashboard?.completedLessons ?? 0 },
    { label: "Phút học", value: dashboard?.studyTimeMinutes ?? 0 },
    { label: "Ngày streak", value: dashboard?.streakDays ?? 0 },
  ];

  return (
    <div className="student-page">
      <section className="student-hero">
        <div>
          <span className="page-badge">Student Dashboard</span>
          <h2>Hôm nay học gì?</h2>
          <p>
            Theo dõi khóa đang học, streak, thời gian học và những kỹ năng cần
            tập trung để tiến bộ đều hơn mỗi ngày.
          </p>
          <div className="student-hero-actions">
            <Link className="page-action page-action-primary" to="/student/courses">Tiếp tục học</Link>
            <Link className="page-action page-action-secondary" to="/student/progress">Xem tiến độ</Link>
          </div>
        </div>

        <aside className="student-focus-card">
          <span>Gợi ý hôm nay</span>
          <strong>{dashboard?.recommendedLessonTitle || "Ôn từ vựng và hoàn thành bài gần nhất"}</strong>
          <p>{dashboard?.weakestSkill?.skill ? `Tập trung kỹ năng: ${dashboard.weakestSkill.skill}` : "Hệ thống sẽ gợi ý khi bạn có thêm dữ liệu học tập."}</p>
        </aside>
      </section>

      {error && <p className="auth-error">{error}</p>}
      {!dashboard && !error && <LoadingState title="Đang tải dashboard..." />}

      {dashboard && (
        <>
          <section className="student-stat-grid">
            {stats.map((item) => (
              <article className="student-stat-card" key={item.label}>
                <span>{item.label}</span>
                <strong>{item.value}</strong>
              </article>
            ))}
          </section>

          <section className="student-dashboard-grid">
            <article className="student-panel">
              <div className="student-panel-head">
                <div>
                  <span className="page-badge">Weekly</span>
                  <h3>Biểu đồ tuần</h3>
                </div>
                <Link to="/student/progress">Chi tiết</Link>
              </div>
              <MiniBarChart items={dashboard.weeklyChart ?? []} />
            </article>

            <article className="student-panel">
              <div className="student-panel-head">
                <div>
                  <span className="page-badge">Skills</span>
                  <h3>Kỹ năng</h3>
                </div>
              </div>
              <div className="student-skill-list">
                <p><span>Mạnh nhất</span><strong>{dashboard.strongestSkill?.skill || "Chưa có dữ liệu"}</strong></p>
                <p><span>Cần cải thiện</span><strong>{dashboard.weakestSkill?.skill || "Chưa có dữ liệu"}</strong></p>
                <p><span>Từ đã học</span><strong>{dashboard.learnedWords ?? 0}</strong></p>
                <p><span>Từ đã nhớ</span><strong>{dashboard.rememberedWords ?? 0}</strong></p>
              </div>
            </article>
          </section>
        </>
      )}
    </div>
  );
}

