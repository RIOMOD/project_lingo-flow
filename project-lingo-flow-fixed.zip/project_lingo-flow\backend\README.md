# Backend scaffold

Thu muc nay la bo khung backend cho du an `He thong ho tro hoc tieng Anh thong minh`.

Kien truc backend hien tai dung kieu `layer-first`, de nhom nho de nhin va de code:

- `controller`: dat cac file nhu `CourseController`, `OrderController`
- `service`: dat cac interface/use case nhu `CourseService`, `OrderCalculationService`
- `service/impl`: dat cac class hien thuc service
- `repository`: dat cac file nhu `CourseRepository`, `UserRepository`
- `entity`: dat cac entity nhu `Course`, `User`, `Order`
- `dto`: dat request/response DTO, co the chia tiep theo nhom `auth`, `course`, `payment`
- `mapper`: dat cac mapper nhu `CourseMapper`, `UserMapper`
- `payment`, `event`, `listener`, `scheduler` cho thanh toan va xu ly bat dong bo

Huong dan khoi tao va chay backend xem:

- `docs/backend/01-spring-boot-initialization.md`

Chi tiet thiet ke xem:

- `docs/architecture/01-system-architecture.md`

## Bien moi truong

Backend doc cau hinh tu bien moi truong trong `application.yml`. Copy file mau:

```powershell
Copy-Item backend\.env.example backend\.env
```

Spring Boot khong tu nap `.env` nhu frontend. Khi chay PowerShell, set bien truoc khi chay:

```powershell
$env:DB_URL="jdbc:mysql://localhost:3306/english_learning?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Ho_Chi_Minh"
$env:DB_USERNAME="root"
$env:DB_PASSWORD="mat_khau_mysql_cua_ban"
$env:FRONTEND_URL="http://localhost:5173"
$env:OPENAI_API_KEY="neu_dung_ai_that"
```

Chay backend on dinh tren Windows:

```powershell
cd backend
.\mvnw.cmd -DskipTests package
java -jar target\english-learning-backend-0.0.1-SNAPSHOT.jar
```
