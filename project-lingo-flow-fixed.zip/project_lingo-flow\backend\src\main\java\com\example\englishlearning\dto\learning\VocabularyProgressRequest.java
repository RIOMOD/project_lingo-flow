package com.example.englishlearning.dto.learning;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VocabularyProgressRequest {

    @Min(0)
    @Max(5)
    private Integer masteryLevel;

    private Boolean remembered;
    private Boolean difficult;
    private Boolean favorite;
}
