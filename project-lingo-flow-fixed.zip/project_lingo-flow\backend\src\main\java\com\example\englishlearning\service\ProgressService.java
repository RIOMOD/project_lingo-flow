package com.example.englishlearning.service;

import com.example.englishlearning.dto.progress.CourseProgressResponse;
import com.example.englishlearning.dto.progress.LessonProgressRequest;
import com.example.englishlearning.dto.progress.ProgressDashboardResponse;

import java.util.List;

public interface ProgressService {
    ProgressDashboardResponse getStudentDashboard(String email);
    List<CourseProgressResponse> getCourseProgress(String email);
    CourseProgressResponse getCourseProgress(String email, Long courseId);
    CourseProgressResponse startLesson(String email, Long lessonId, LessonProgressRequest request);
    CourseProgressResponse completeLesson(String email, Long lessonId, LessonProgressRequest request);
    ProgressDashboardResponse getTeacherDashboard(String email);
}
