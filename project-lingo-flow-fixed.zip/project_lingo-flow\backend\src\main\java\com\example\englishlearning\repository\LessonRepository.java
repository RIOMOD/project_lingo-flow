package com.example.englishlearning.repository;

import com.example.englishlearning.entity.Lesson;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LessonRepository extends JpaRepository<Lesson, Long> {

    List<Lesson> findByChapterIdAndDeletedAtIsNullOrderByPositionAsc(Long chapterId);

    Optional<Lesson> findByIdAndChapterCourseIdAndDeletedAtIsNull(Long id, Long courseId);

    List<Lesson> findByChapterCourseIdAndDeletedAtIsNullOrderByPositionAsc(Long courseId);

    long countByChapterCourseIdAndDeletedAtIsNull(Long courseId);
}
