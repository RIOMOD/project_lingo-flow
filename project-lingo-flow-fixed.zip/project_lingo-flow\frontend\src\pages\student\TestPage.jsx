import { useEffect, useState } from "react";
import { getAttempts, getTests, saveAnswer, startTest, submitAttempt } from "../../services/assessmentService";

export default function TestPage() {
  const [items, setItems] = useState([]);
  const [history, setHistory] = useState([]);
  const [attempt, setAttempt] = useState(null);
  const [error, setError] = useState("");

  async function load() {
    const [testData, attemptData] = await Promise.all([getTests({ size: 20 }), getAttempts({ size: 10 })]);
    setItems(testData?.items ?? []);
    setHistory(attemptData?.items ?? []);
  }

  useEffect(() => {
    load().catch((err) => setError(err.message || "Khong tai duoc bai kiem tra"));
  }, []);

  async function begin(id) {
    try {
      setAttempt(await startTest(id));
    } catch (err) {
      setError(err.message || "Khong bat dau duoc bai kiem tra");
    }
  }

  async function answer(question, value) {
    setAttempt(await saveAnswer(attempt.id, question.id, { selectedOptionId: value ? Number(value) : null }));
  }

  async function submit() {
    setAttempt(await submitAttempt(attempt.id));
    await load();
  }

  return (
    <div className="course-page">
      <section className="page-hero">
        <span className="page-badge">Tests</span>
        <h2 className="page-title">Bai kiem tra</h2>
        <p className="page-description">Moi lan lam tao attempt rieng, het gio khong the nop/sua.</p>
      </section>
      {error && <p className="auth-error">{error}</p>}
      {!attempt && (
        <>
          <section className="course-table page-panel-card">
            {items.map((item) => (
              <div className="course-table-row" key={item.id}>
                <div>
                  <strong>{item.title}</strong>
                  <p>{item.durationMinutes} phut - toi da {item.maxAttempts} lan</p>
                </div>
                <button className="page-action page-action-primary" onClick={() => begin(item.id)}>Bat dau</button>
              </div>
            ))}
          </section>
          <section className="course-table page-panel-card">
            <h3>Lich su lam bai</h3>
            {history.map((item) => (
              <div className="course-table-row" key={item.id}>
                <div><strong>{item.title}</strong><p>{item.status} - {item.score ?? "Chua co diem"}</p></div>
              </div>
            ))}
          </section>
        </>
      )}
      {attempt && (
        <section className="page-panel-card">
          <h3>{attempt.title}</h3>
          <p>{attempt.status} {attempt.score !== null && attempt.score !== undefined ? `- Diem: ${attempt.score}` : ""}</p>
          {(attempt.questions ?? []).map((question) => (
            <div className="page-panel-card" key={question.id}>
              <strong>{question.questionText}</strong>
              {(question.options ?? []).map((option) => (
                <label key={option.id} className="lesson-row">
                  <input type="radio" name={`q-${question.id}`} disabled={attempt.status !== "IN_PROGRESS"} onChange={(event) => answer(question, event.target.value)} value={option.id} />
                  <span>{option.optionText}</span>
                </label>
              ))}
              {attempt.status !== "IN_PROGRESS" && <p>{question.explanation}</p>}
            </div>
          ))}
          {attempt.status === "IN_PROGRESS" && <button className="page-action page-action-primary" onClick={submit}>Nop bai</button>}
        </section>
      )}
    </div>
  );
}
