import { createConfiguredPage } from "../../components/common/createConfiguredPage";

export default createConfiguredPage("adminDashboard");
