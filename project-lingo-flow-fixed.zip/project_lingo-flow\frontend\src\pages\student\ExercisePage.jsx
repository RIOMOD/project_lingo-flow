import { useEffect, useState } from "react";
import { getExercises, saveAnswer, startExercise, submitAttempt } from "../../services/assessmentService";

export default function ExercisePage() {
  const [items, setItems] = useState([]);
  const [attempt, setAttempt] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getExercises({ size: 20 })
      .then((data) => setItems(data?.items ?? []))
      .catch((err) => setError(err.message || "Khong tai duoc bai tap"));
  }, []);

  async function begin(id) {
    try {
      setAttempt(await startExercise(id));
    } catch (err) {
      setError(err.message || "Khong bat dau duoc bai tap");
    }
  }

  async function answer(question, value) {
    try {
      setAttempt(await saveAnswer(attempt.id, question.id, { selectedOptionId: value ? Number(value) : null }));
    } catch (err) {
      setError(err.message || "Khong luu duoc dap an");
    }
  }

  async function submit() {
    try {
      setAttempt(await submitAttempt(attempt.id));
    } catch (err) {
      setError(err.message || "Khong nop duoc bai");
    }
  }

  return (
    <div className="course-page">
      <section className="page-hero">
        <span className="page-badge">Exercises</span>
        <h2 className="page-title">Bai tap</h2>
        <p className="page-description">Bat dau attempt, luu tam dap an va nop bai de xem diem.</p>
      </section>
      {error && <p className="auth-error">{error}</p>}
      {!attempt && (
        <section className="course-table page-panel-card">
          {items.map((item) => (
            <div className="course-table-row" key={item.id}>
              <div>
                <strong>{item.title}</strong>
                <p>{item.description} - {item.durationMinutes || "Khong gioi han"} phut</p>
              </div>
              <button className="page-action page-action-primary" onClick={() => begin(item.id)}>Lam bai</button>
            </div>
          ))}
        </section>
      )}
      {attempt && (
        <section className="page-panel-card">
          <h3>{attempt.title}</h3>
          <p>Trang thai: {attempt.status} {attempt.score !== null && attempt.score !== undefined ? `- Diem: ${attempt.score}` : ""}</p>
          {(attempt.questions ?? []).map((question) => (
            <div className="page-panel-card" key={question.id}>
              <strong>{question.questionText}</strong>
              {(question.options ?? []).map((option) => (
                <label key={option.id} className="lesson-row">
                  <input type="radio" name={`q-${question.id}`} disabled={attempt.status !== "IN_PROGRESS"} onChange={(event) => answer(question, event.target.value)} value={option.id} />
                  <span>{option.optionText}</span>
                </label>
              ))}
              {attempt.status !== "IN_PROGRESS" && <p>{question.explanation}</p>}
            </div>
          ))}
          {attempt.status === "IN_PROGRESS" && <button className="page-action page-action-primary" onClick={submit}>Nop bai</button>}
        </section>
      )}
    </div>
  );
}
