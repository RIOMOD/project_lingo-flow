import { useEffect, useState } from "react";
import { createChapter, createLesson, getTeacherCourses } from "../../services/courseService";

export default function LessonBuilderPage() {
  const [courses, setCourses] = useState([]);
  const [courseId, setCourseId] = useState("");
  const [chapterId, setChapterId] = useState("");
  const [chapterTitle, setChapterTitle] = useState("");
  const [lessonTitle, setLessonTitle] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    getTeacherCourses({ size: 50 })
      .then((data) => setCourses(data?.items ?? []))
      .catch((err) => setError(err.message || "Khong tai duoc khoa hoc"));
  }, []);

  async function handleCreateChapter(event) {
    event.preventDefault();
    setError("");
    try {
      const chapter = await createChapter(courseId, {
        title: chapterTitle,
        description: "",
        position: 1,
      });
      setChapterId(String(chapter.id));
      setChapterTitle("");
      setMessage("Da tao chapter. Ban co the tao lesson trong chapter nay.");
    } catch (err) {
      setError(err.message || "Khong tao duoc chapter");
    }
  }

  async function handleCreateLesson(event) {
    event.preventDefault();
    setError("");
    try {
      await createLesson(chapterId, {
        title: lessonTitle,
        lessonType: "TEXT",
        content: "Noi dung bai hoc dang duoc cap nhat.",
        position: 1,
        durationMinutes: 10,
        preview: true,
        status: "PUBLISHED",
      });
      setLessonTitle("");
      setMessage("Da tao lesson hoc thu.");
    } catch (err) {
      setError(err.message || "Khong tao duoc lesson");
    }
  }

  return (
    <div className="course-page">
      <section className="page-hero">
        <span className="page-badge">Teacher</span>
        <h2 className="page-title">Quan ly chapter va lesson</h2>
        <p className="page-description">Tao nhanh chapter va lesson hoc thu cho khoa hoc cua ban.</p>
      </section>
      {error && <p className="auth-error">{error}</p>}
      {message && <p className="course-success">{message}</p>}
      <section className="course-detail-body">
        <form className="course-form page-panel-card" onSubmit={handleCreateChapter}>
          <h3>Tao chapter</h3>
          <label>
            Khoa hoc
            <select required value={courseId} onChange={(event) => setCourseId(event.target.value)}>
              <option value="">Chon khoa hoc</option>
              {courses.map((course) => <option key={course.id} value={course.id}>{course.title}</option>)}
            </select>
          </label>
          <label>
            Ten chapter
            <input required value={chapterTitle} onChange={(event) => setChapterTitle(event.target.value)} />
          </label>
          <button className="page-action page-action-primary">Tao chapter</button>
        </form>

        <form className="course-form page-panel-card" onSubmit={handleCreateLesson}>
          <h3>Tao lesson hoc thu</h3>
          <label>
            Chapter ID
            <input required value={chapterId} onChange={(event) => setChapterId(event.target.value)} />
          </label>
          <label>
            Ten lesson
            <input required value={lessonTitle} onChange={(event) => setLessonTitle(event.target.value)} />
          </label>
          <button className="page-action page-action-primary">Tao lesson</button>
        </form>
      </section>
    </div>
  );
}
