package com.example.englishlearning.dto.assessment;

import com.example.englishlearning.entity.TestAttempt;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Builder
public class AttemptResponse {
    private Long id;
    private String targetType;
    private Long targetId;
    private String title;
    private LocalDateTime startedAt;
    private LocalDateTime dueAt;
    private LocalDateTime submittedAt;
    private BigDecimal score;
    private TestAttempt.AttemptStatus status;
    private List<QuestionResponse> questions;
    private List<AnswerResultResponse> answers;
}
